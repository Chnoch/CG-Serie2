package jrtr;

/**
 * Stores the properties of a light source. To be implemented for 
 * the "Texturing and Shading" project.
 */
public class Light {
}
